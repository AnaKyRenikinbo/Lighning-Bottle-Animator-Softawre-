#!/bin/bash
# Lightning Bottle Animator Uninstallation Script
# Run with: sudo ./uninstall.sh

set -e

APP_NAME="lightning-bottle-animator"
APP_DIR="/opt/$APP_NAME"
BIN_LINK="/usr/local/bin/lightning-bottle-animator"
DESKTOP_FILE="/usr/share/applications/lightning-bottle-animator.desktop"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     Lightning Bottle Animator - Uninstallation Script        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check for root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run as root (sudo ./uninstall.sh)"
    exit 1
fi

# Remove application directory
if [ -d "$APP_DIR" ]; then
    echo "🗑️  Removing application directory..."
    rm -rf "$APP_DIR"
else
    echo "ℹ️  Application directory not found."
fi

# Remove symbolic link
if [ -L "$BIN_LINK" ]; then
    echo "🔗 Removing symbolic link..."
    rm -f "$BIN_LINK"
else
    echo "ℹ️  Symbolic link not found."
fi

# Remove desktop entry
if [ -f "$DESKTOP_FILE" ]; then
    echo "🖥️  Removing desktop entry..."
    rm -f "$DESKTOP_FILE"
    update-desktop-database /usr/share/applications 2>/dev/null || true
else
    echo "ℹ️  Desktop entry not found."
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                ✅ Uninstallation Complete!                   ║"
echo "╚══════════════════════════════════════════════════════════════╝"