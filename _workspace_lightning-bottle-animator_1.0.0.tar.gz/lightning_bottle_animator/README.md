# ⚡ Lightning Bottle Animator

A retro-styled animation and drawing application for Linux Mint, inspired by classic tools like Deluxe Paint and featuring a nostalgic 2000s web design aesthetic.

![Lightning Bottle Animator](https://img.shields.io/badge/Version-1.0.0-blue.svg)
![Platform](https://img.shields.io/badge/Platform-Linux%20Mint-green.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## ✨ Features

### 🎨 Drawing Tools
- **Brush Tool** - Freehand painting with adjustable size
- **Airbrush** - Smooth spray painting effect
- **Line Tool** - Draw straight lines
- **Rectangle Tool** - Filled and outline rectangles
- **Circle Tool** - Filled and outline circles
- **Ellipse Tool** - Filled and outline ellipses
- **Fill Tool** - Flood fill enclosed areas
- **Eraser** - Erase with adjustable size
- **Eyedropper** - Pick colors from canvas
- **Selection Tool** - Select areas and pick up brushes
- **Text Tool** - Place text on canvas

### 🎭 Character Templates
Pre-built character templates inspired by classic animation books:
- Comic Book Heroes
- Retro Cartoon Characters
- Cute Animals
- Robots & Mechs
- Fantasy Characters
- Aliens & Creatures

### 📚 Layer System
- Multiple layers with visibility controls
- Layer reordering (move up/down)
- Per-layer editing
- Layer opacity support

### 🎬 Animation Timeline
- Frame-by-frame animation
- Playback controls (play, pause, first, last, next, prev)
- Adjustable FPS (1-60)
- Frame duplication
- Thumbnail previews

### 🎨 Color Palette
- 32 preset colors
- Custom color picker
- Foreground/background color system
- Quick fill colors

### 🖼️ File Support
- Open PNG, JPG, GIF, BMP images
- Save as PNG, JPG, GIF
- Export animations (GIF)

## 🚀 Installation

### Quick Install
```bash
# Extract the archive
tar -xzf lightning-bottle-animator.tar.gz
cd lightning-bottle-animator

# Run the installer
sudo ./install.sh
```

### Manual Install
```bash
# Install dependencies
sudo apt-get install python3 python3-pip python3-tk
pip3 install Pillow

# Run directly
python3 src/main.py
```

## 🎮 Usage

### Launch the Application
- **From Menu**: Menu → Graphics → Lightning Bottle Animator
- **From Terminal**: `lightning-bottle-animator`

### Keyboard Shortcuts
| Shortcut | Action |
|----------|--------|
| Ctrl+N | New Project |
| Ctrl+O | Open Image |
| Ctrl+S | Save Image |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| F5 | Play/Pause Animation |

## 🎨 Drawing Tips

### Retro Cartoon Style (2000s Inspired)
1. Start with the Character Templates for quick character bases
2. Use bold outlines with the brush tool
3. Fill with vibrant, saturated colors
4. Add highlights with lighter shades
5. Use the symmetry feature for balanced designs

### Animation Workflow
1. Create your first frame
2. Use the "+" button to add new frames
3. Copy frames to maintain consistency
4. Adjust FPS for desired speed
5. Preview with the play button

## 📁 Project Structure
```
lightning_bottle_animator/
├── src/
│   └── main.py          # Main application code
├── install.sh           # Installation script
├── uninstall.sh         # Uninstallation script
├── requirements.txt     # Python dependencies
└── README.md            # This file
```

## 🛠️ Requirements
- Python 3.6+
- tkinter (usually included with Python)
- Pillow (PIL)

## 📜 License
MIT License - Feel free to modify and distribute!

## 🙏 Credits
Inspired by:
- Deluxe Paint V (Electronic Arts)
- "How to Animate Film Cartoons" by Preston Blair
- "Cartoon Cool: How to Draw New Retro-Style Characters" by Christopher Hart
- "How to Draw Comic Book Heroes" by Christopher Hart

---
*Created with ⚡ by Lightning Bottle Studios*