#!/bin/bash
cd /opt/lightning-bottle-animator
python3 src/main.py "$@"